import 'package:flutter/material.dart';
import 'page_about_app.dart';

class ProfileScreen extends StatefulWidget {
  final double totalPrice;

  const ProfileScreen({super.key, required this.totalPrice});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String _selectedPaymentMethod = 'Visa';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // User Profile Section
              Center(
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 50.0,
                      backgroundImage: NetworkImage('https://i.pinimg.com/736x/f5/1f/df/f51fdf8b172848765e78407d9b624b10.jpg'),
                    ),
                    const SizedBox(height: 16.0),
                    const Text(
                      'Hend Mohamed',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8.0),
                    Text(
                      'Email: hendmohamed@gmail.com',
                      style: const TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Phone: +1-456-558-158',
                      style: const TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 45.0),

              // Total Price Section
              const Text(
                'Total Price of Selected Items:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold,
                color: Colors.purple,fontStyle: FontStyle.italic),
              ),
              Text(
                '\$${widget.totalPrice.toStringAsFixed(2)}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 40.0),

              // Payment Method Section
              const Text(
                'Select Payment Method:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16.0),
              PaymentMethodOption(
                method: 'Visa',
                isSelected: _selectedPaymentMethod == 'Visa',
                onChanged: () {
                  setState(() {
                    _selectedPaymentMethod = 'Visa';
                  });
                },
              ),
              PaymentMethodOption(
                method: 'Vodafone Cash',
                isSelected: _selectedPaymentMethod == 'Vodafone Cash',
                onChanged: () {
                  setState(() {
                    _selectedPaymentMethod = 'Vodafone Cash';
                  });
                },
              ),
              const SizedBox(height: 24.0),

              // Done Button
              Align(
                alignment: Alignment.bottomRight,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const PageAboutApp(),
                      ),
                    );
                  },
                  child: const Text('Done'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PaymentMethodOption extends StatelessWidget {
  final String method;
  final bool isSelected;
  final VoidCallback onChanged;

  const PaymentMethodOption({
    super.key,
    required this.method,
    required this.isSelected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(method),
      leading: Radio<String>(
        value: method,
        groupValue: isSelected ? method : null,
        onChanged: (value) {
          onChanged();
        },
      ),
      onTap: onChanged,
    );
  }
}
