import 'package:flutter/material.dart';
import 'info_screen.dart';

class PageAboutApp extends StatelessWidget {
  const PageAboutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About This App'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '# About This App',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Text(
                'This application was built using Flutter and Android Studio. The app connects to a remote API to fetch and display products from various categories. '
                    'The following tools and services were used in the development of this app:',
                style: TextStyle(fontSize: 20, fontStyle: FontStyle.italic, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),
              const Text(
                '1 - Android Studio',
                style: TextStyle(fontSize: 25, color: Colors.purple),
              ),
              const SizedBox(height: 25),
              const Text(
                '2 - Postman',
                style: TextStyle(fontSize: 25, color: Colors.purple),
              ),
              const SizedBox(height: 25),
              const Text(
                '3 - DummyJSON',
                style: TextStyle(fontSize: 25, color: Colors.purple),
              ),
              const SizedBox(height: 25),
              const Text(
                '4 - Quicktype',
                style: TextStyle(fontSize: 25, color: Colors.purple),
              ),
              const SizedBox(height: 25),
              const Text(
                '5 - pub.dev',
                style: TextStyle(fontSize: 25, color: Colors.purple),
              ),
              const SizedBox(height: 24),
              const Text(
                'The app displays products from different categories. Each product can be added to a cart, and users can view their selected items and total price.',
                style: TextStyle(fontSize: 20, fontStyle: FontStyle.italic, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const InfoScreen(),
                      ),
                    );
                  },
                  child: const Text('Next'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
