import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';

import 'home_screenn.dart';

class WelcomeScreen extends StatelessWidget {
  WelcomeScreen({super.key});

  final List<PageViewModel> pages = [
    PageViewModel(
      title: 'Welcome to MyApp',
      body: 'Click on the arrow to discover the application.',
      image: Center(
        child: Image.network(
          'https://static.vecteezy.com/system/resources/previews/001/993/379/original/app-development-concept-illustration-free-vector.jpg',
          height: 200,
          width: 350,
          fit: BoxFit.cover,
        ),
      ),
      decoration: const PageDecoration(
        titleTextStyle: TextStyle(
          fontSize: 28.0,
          fontWeight: FontWeight.bold,
        ),
        bodyTextStyle: TextStyle(fontSize: 18.0),
      ),
    ),
    PageViewModel(
      title: 'Explore Features',
      body: 'Discover the amazing features we offer.',
      image: Center(
        child: Image.network(
          'https://www.nicepng.com/png/full/81-814614_apps-vector-hand-holding-phone-illustration-mobile-app.png',
          fit: BoxFit.cover,
        ),
      ),
      decoration: const PageDecoration(
        titleTextStyle: TextStyle(
          fontSize: 28.0,
          fontWeight: FontWeight.bold,
        ),
        bodyTextStyle: TextStyle(fontSize: 18.0),
      ),
    ),
    PageViewModel(
      title: 'Get Started',
      body: 'Let\'s get started with using MyApp!',
      image: Center(
        child: Image.network(
          'https://static.vecteezy.com/system/resources/previews/016/331/210/non_2x/let-s-start-button-web-banner-templates-illustration-vector.jpg',
          fit: BoxFit.cover,
        ),
      ),
      decoration: const PageDecoration(
        titleTextStyle: TextStyle(
          fontSize: 28.0,
          fontWeight: FontWeight.bold,
        ),
        bodyTextStyle: TextStyle(fontSize: 18.0),
      ),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IntroductionScreen(
        pages: pages,
        dotsDecorator: const DotsDecorator(
          size: Size(10, 10),
          color: Colors.blue,
          activeSize: Size.square(15),
          activeColor: Colors.red,
          spacing: EdgeInsets.symmetric(horizontal: 3.0),
        ),
        showDoneButton: true,
        done: const Text(
          'Done',
          style: TextStyle(fontSize: 20),
        ),
        showSkipButton: true,
        skip: const Text(
          'Skip',
          style: TextStyle(fontSize: 20),
        ),
        showNextButton: true,
        next: const Icon(
          Icons.arrow_forward,
          size: 20,
        ),
        onDone: () => onDone(context),
      ),
    );
  }

  void onDone(BuildContext context) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => const HomeScreenn()),
    );
  }
}