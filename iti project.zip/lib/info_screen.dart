import 'package:flutter/material.dart';

class InfoScreen extends StatelessWidget {
  const InfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Info Screen'),
        centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Space at the top
          const SizedBox(height: 100.0),

          // Profile picture
          const Center(
            child: CircleAvatar(

              backgroundImage: NetworkImage('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEit3B0COrOhg6R6k9NJ8oS3VhwL0E2wYkysGo16beJ-EaTEkhpVE6IqNhXh7TOqFqfMZJ8iZuzz6Z858gq4NU0X5m0st553FHDrKLWCXPHK7Fm3_7LAZUvo8sTFfA17FtuV8LgMzcX2MLaXT_z4BSIbjqeHACT0CzekNyirYHdNA8ANLZED5qxGvXI5/s1080/%D8%B5%D9%88%D8%B1-%D8%A8%D9%86%D8%A7%D8%AA-%D9%85%D9%86%D9%82%D8%A8%D8%A7%D8%AA-%D9%85%D8%B1%D8%B3%D9%88%D9%85%D9%87-%D8%AF%D9%8A%D8%AC%D9%8A%D8%AA%D8%A7%D9%84-%D8%A7%D8%B1%D8%A7%D8%AA-17.jpg'),
            ),
          ),
          const SizedBox(height: 40.0),

          // Text information
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0), // Padding for text
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name
                Text(
                  'Name: Hend Mohamed Mohamed Ibrahim',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 20.0),

                // College
                Text(
                  'Faculty: Computer and Information Sciences',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(height: 20.0),

                // University
                Text(
                  'University: Mansoura University',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(height: 20.0),

                // Track
                Text(
                  'Track: Mobile Application Using Flutter',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(height: 20.0),

                // Age
                Text(
                  'Age: 21 years',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(height: 24.0),
              ],
            ),
          ),

          const Spacer(),

          // Social icons
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // WhatsApp icon
                IconButton(
                  icon: const Icon(Icons.chat, color: Colors.green, size: 30),
                  onPressed: () {

                  },
                ),
                const SizedBox(width: 32.0),
                // Facebook icon
                IconButton(
                  icon: const Icon(Icons.facebook, color: Colors.blue, size: 30),
                  onPressed: () {

                  },
                ),
                const SizedBox(width: 32.0),
                // Phone icon
                IconButton(
                  icon: const Icon(Icons.phone, color: Colors.red, size: 30),
                  onPressed: () {

                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
