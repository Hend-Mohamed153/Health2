import 'package:http/http.dart' as http;
import 'dart:convert';
import 'stories_model.dart';

Future<StoriesModel> login(String username, String password) async {
  final response = await http.post(
    Uri.parse('https://dummyjson.com/auth/login'),
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
    body: jsonEncode(<String, String>{
      'username': username,
      'password': password,
    }),
  );

  if (response.statusCode == 200) {
    final responseData = jsonDecode(response.body);
    return StoriesModel.fromJson(responseData);
  } else {
    throw Exception('Failed to login');
  }
}
