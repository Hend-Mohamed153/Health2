import 'dart:convert';
import 'package:http/http.dart' as http;
import 'stories_product.dart';

class Api {
  final String baseUrl = 'https://dummyjson.com/products';

  Future<AboutModel> fetchProducts() async {
    final response = await http.get(Uri.parse(baseUrl));

    if (response.statusCode == 200) {
      return aboutModelFromJson(response.body);
    } else {
      throw Exception('Failed to load products');
    }
  }
}
