import 'package:flutter/material.dart';
import 'page_about_app.dart';

class AboutAppScreen extends StatelessWidget {
  const AboutAppScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About This App'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'About Our App',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            const Text(
              'Our website displays sections for products of different types. We provide you with a picture of the product and its price,'
                  ' and there are payment methods for you to choose what suits you.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 24),
            const Text(
              'Features:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              '• easy to use\n• Notifications\n• User-friendly Interface',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 30),
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: 2,
              crossAxisSpacing: 16.0,
              mainAxisSpacing: 16.0,
              childAspectRatio: 1.0,
              children: [
                _buildImageSection(
                  'https://tse2.mm.bing.net/th?id=OIP.3TdcQMkEdjMxSiizWdJdpQHaE7&pid=Api&P=0&h=220',
                  'Perfume',
                  'There are different and fixed scents.',
                ),
                _buildImageSection(
                  'https://tse4.explicit.bing.net/th?id=OIP.slWIBio7DZP1TckT9w7OlQHaEK&pid=Api&P=0&h=220',
                  'Skin Care',
                  'There are special products for hair and skin.',
                ),
              ],
            ),
            const SizedBox(height: 24),
            Center(
              child: _buildImageSection(
                'https://new3.co/wp-content/uploads/2020/02/8763-2.jpg',
                'Healthy Food',
                'Various healthy and useful foods.',
              ),
            ),
            const SizedBox(height: 24),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const PageAboutApp(),
                    ),
                  );
                },
                child: const Text('Done'),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSection(String imageUrl, String title, String description) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 100.0,
          height: 100.0,
          child: Image.network(
            imageUrl,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(height: 8.0),
        Text(
          title,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        Text(
          description,
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ],
    );
  }
}
